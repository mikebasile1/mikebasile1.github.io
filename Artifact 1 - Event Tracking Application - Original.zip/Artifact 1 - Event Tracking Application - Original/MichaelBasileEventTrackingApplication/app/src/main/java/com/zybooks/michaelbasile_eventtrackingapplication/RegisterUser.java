package com.zybooks.michaelbasile_eventtrackingapplication;

public class RegisterUser {
}
